<?php

return [
    "profilePicPath" => 'public/images/ret_ail_ers/',
    "articlePicPath" => 'public/images/ret_ail_ers/articles/'
];