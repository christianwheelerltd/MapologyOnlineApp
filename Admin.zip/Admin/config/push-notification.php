<?php

return array(

    'appNameIOS'     => array(
        'environment' =>'development',
        'certificate' => public_path('push.pem'),
        'passPhrase'  =>'',
        'service'     =>'apns'
    ),
    'appNameAndroid' => array(
        'environment' =>'production',
        'apiKey'      =>'AIzaSyC_LSXQeUARMbf5a1uJP_9zeled8HMVhdg',
        'service'     =>'gcm'
    )

);