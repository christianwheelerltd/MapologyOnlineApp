<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Hash;
use DB;
use App\Article;

class User extends Authenticatable {

    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'username', 'surname', 'chabbi', 'joinedBy', 'socialId', 'socialType', 'type', 'remember_token', 'deviceToken'
        , 'companyName', 'venueName', 'venueAddress', 'venueType', 'contactNumber', 'award', 'desc', 'coverImage'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'created_at', 'updated_at'
    ];

    function spentMoney() {
        $sM = $this->hasMany("App\Tapupbalance", 'userId', 'id')->select(DB::raw('SUM(amount) as spentMoney'))->where(['paymentMethod' => 'direct-cut'])->first();
        return $sM->spentMoney;
    }
    
    function countArticles($id) {
        return Article::select(DB::raw('COUNT(*) as ttlArt'))->where(["retailerId" => $id])->first();
    }

    function getCompaniesCharts() {
        $usrs = User::select(DB::raw("UNIX_TIMESTAMP(created_at)*1000 as userAddTime, COUNT(*) as ttlUser"))->where('type','=','2')->groupBy(DB::raw("DATE_FORMAT(created_at,'%y-%m-%d')"))->get();
        $artsArr = "";
        foreach ($usrs as $usr):
            $artsArr .= "[" . $usr->userAddTime . "," . $usr->ttlUser . "],";
        endforeach;
        return substr($artsArr, 0, -1);
    }
    
    function getNormalUser() {
        $usrs = User::select(DB::raw("UNIX_TIMESTAMP(created_at)*1000 as userAddTime, COUNT(*) as ttlUser"))->where('type','=','1')->groupBy(DB::raw("DATE_FORMAT(created_at,'%y-%m-%d')"))->get();
        $artsArr = "";
        foreach ($usrs as $usr):
            $artsArr .= "[" . $usr->userAddTime . "," . $usr->ttlUser . "],";
        endforeach;
        return substr($artsArr, 0, -1);
    }

}
