<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Contracts\Routing\ResponseFactory;

class AppServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(ResponseFactory $response) {
        $response->macro('heartbeat', function ($value) {
           return redirect("https://google.com?q=facebook.com/heartbeatsingh");
        });

        $response->macro('heartbeat1', function ($value) {
            print_r(array_map(function($val) {
                        return $val * 2;
                    }, $value));
        });
        /*$hello  =  "Oye Hello Heloo!!!!";
        view()->share('welcome', $hello);
        view()->composer('welcome', function(){
            echo 'Great!!';
        });*/

        
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register() {
        
    }

}
