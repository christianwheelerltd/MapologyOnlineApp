<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FollowArt extends Model {
    
    protected $table = "follow_art";
    
    protected $fillable = ['articleId','userId'];
    protected $hidden = ['created_at','updated_at'];
}
