<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tapupbalance extends Model {

    protected $table = "tap_up_balance_history";
    protected $fillable = ['userId','amount','status','paymentMethod'];
    
    
    function paymentOwner(){
        return $this->hasOne("App\User","id",'userId')->select("companyName");
    }
}
