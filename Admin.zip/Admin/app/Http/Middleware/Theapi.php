<?php

namespace App\Http\Middleware;

use Closure;

class Theapi {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        if ($request->isMethod('POST')) {
            $req = ['api/register', 'api/login', 'api/forgotPassword'];
            if (in_array($request->path(), $req)) {
                return $next($request);
            } else {
                $validateArr = $request->json()->all();
                if (!empty($validateArr['data'])) {
                    extract($validateArr['data']);
                    if (empty($userId) || empty($token)) {
                        return response()->json(['status' => 0, 'message' => 'user authentication failed.']);
                    }
                    $isExist = isAuthUser($userId, $token);
                    if ($isExist) {
                        return $next($request);
                    } else {
                        return response()->json(['status' => 0, 'message' => 'user authentication failed.']);
                    }
                } else {
                    return response()->json(['status' => 0, 'message' => 'Data is empty.']);
                }
            }
        } else {
            return response()->json(['status' => 0, 'message' => 'Request method is not valid.']);
        }
    }

}
