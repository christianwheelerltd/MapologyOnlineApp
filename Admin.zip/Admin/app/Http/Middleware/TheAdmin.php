<?php

namespace App\Http\Middleware;

use Closure;
use Auth;

class TheAdmin {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        $user = Auth::user();
        if (!Auth::check()) {
            return redirect(url("admin"));
        }
        if ($user->type == '143' && $user->status == 0) {
            return $next($request);
        } else {
            return redirect(url("/"));
        }
    }

}
