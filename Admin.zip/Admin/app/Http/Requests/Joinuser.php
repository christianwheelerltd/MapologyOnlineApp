<?php

namespace App\Http\Requests;

use Illuminate\Http\Request;
use Illuminate\Foundation\Http\FormRequest;
use Validator;

class Joinuser extends Request {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
        'firstName' => 'required|min:2|max:150',
        'lastName' => 'required|min:2|max:150',
        'socialId' => 'required|min:5|max:150',
        'socialType' => 'required'
        ];
        /* if (!empty($isSocial)) {
          $validator = Validator::make($requestData['data'], [
          'firstName' => 'required|min:2|max:150',
          'lastName' => 'required|min:2|max:150',
          'socialId' => 'required|min:5|max:150',
          'socialType' => 'required'
          ]);
          } else {
          $validator = Validator::make($requestData['data'], [
          'firstName' => 'required|min:2|max:150',
          'lastName' => 'required|min:2|max:150',
          'email' => 'required|min:5|max:150',
          'password' => 'required|min:5|max:150',
          ]);
          } */
        
   
    }
}
