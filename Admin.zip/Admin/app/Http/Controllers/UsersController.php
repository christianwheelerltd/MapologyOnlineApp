<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UsersController extends Controller {
    
    
    
    
    
    /**
     * Admin area Functionality 
     **/

    
}
