<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use PushNotification;




class TestController extends Controller {

    function index(Request $request) {
       $push =  PushNotification::app('appNameIOS')
                ->to("9810F5C8C8C152726A9A12FD129AF54743EA4F4EBE47D652B90DFD45E100042F")
                ->send('Hello World This is heartbeat testing ios');
       
        $push =  PushNotification::app('appNameAndroid')
                ->to("70225b22-0c49-47db-aa04-ea4c07b11118")
                ->send('Hello World This is heartbeat testing android');
       //$push->adp->setAdapterParameters(['sslverifypeer' => false]);
       echo 'sent';
    }

}
