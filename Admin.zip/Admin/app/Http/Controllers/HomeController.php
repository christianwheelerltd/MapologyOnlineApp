<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Article;
use Auth;
use App\Page;

class HomeController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth', ['except' => ['getPages']]);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($order = "") {
        $retailerId = Auth::id();
        $art = new Article;
        if (!empty($order) AND $order == 'atoz') {
            $orderBy = ['title', 'ASC'];
        } else if ($order == 'location') {
            $orderBy = ['lati', 'ASC'];
        } else {
            $orderBy = ['id', 'DESC'];
        }
        $results = $art->where(['retailerId' => $retailerId])->orderBy(current($orderBy), end($orderBy))->paginate(10);
        return view('home', ['results' => $results, 'orderIs' => $order]);
    }

    function getPages($slug = "") {
        $page = Page::where(['slug' => $slug, 'status' => 1]);
        if (!$page->count()) {
            return redirect("/");
        } else {
            $row = $page->first();
            return view('pages.index', ['row' => $row]);
        }
    }

    function faq() {
        return view('faq');
    }

}
