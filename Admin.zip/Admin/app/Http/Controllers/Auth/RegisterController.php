<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use Config;
class RegisterController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Register Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles the registration of new users as well as their
      | validation and creation. By default this controller uses a trait to
      | provide this functionality without requiring any additional code.
      |
     */

use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest');
        if(!Auth::check()){
            return redirect('home');
        }
    }
    

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data) {
        Session::flash('error', "Oops! it's seems, something isn't validate in below form, please check carefully.");
        return Validator::make($data, [
                    'companyName' => 'required|max:150',
                    'venueName' => 'required|max:150',
                    'venueType' => 'required|max:10',
                    'venueAddress' => 'required|max:255',
                    'contactNumber' => 'required|max:100',
                    'award' => 'required',
                    'desc' => 'required',
                    'email' => 'required|email|max:255|unique:users',
                    'password' => 'required|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */


    protected function create(array $data) {
        
        if(!empty($data['coverImage'])){
            $picName = saveProfilePic($data['coverImage'],Config::get('consts.profilePicPath'));
        }else{
            $picName = "";
        }
               
        return User::create([
                    'companyName' => $data['companyName'],
                    'venueName' => $data['venueName'],
                    'venueAddress' => $data['venueAddress'],
                    'venueType' => $data['venueType'],
                    'contactNumber' => $data['contactNumber'],
                    'award' => $data['award'],
                    'desc' => $data['desc'],
                    'coverImage' => $picName,
                    'email' => $data['email'],
                    'chabbi' => $data['password'],
                    'password' => bcrypt($data['password']),
                    'status' => 1,
                    'type' => 2,
        ]);
    }

}