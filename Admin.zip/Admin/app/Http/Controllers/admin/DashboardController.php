<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Article;
use App\User;
use App\Tapupbalance;
use App\Page;
use Validator;
use Session;
use DB;

class DashboardController extends Controller {

    function index() {
        $artsObj = new Article;
        $usrObj = new User;
        $arts  = $artsObj->getArtChart();
        $cats  = $artsObj->getArtByCat();
        $companies = $usrObj->getCompaniesCharts();
        $normalUsers = $usrObj->getNormalUser();
        return view('admin.dashboard',['arts' => $arts,'carts' => $companies,'users' => $normalUsers,'cats' => $cats]);
    }
   
    
    function userList($type = null) {
        $results = User::where(['type' => $type])->orderBy("id", "DESC")->paginate(15);
        return view('admin.userList', ['results' => $results]);
    }

    function articles($retailerId = null) {
        if (!empty($retailerId)) {
            $results = Article::where(['retailerId' => $retailerId])->orderBy("status", "DESC")->paginate(15);
        } else {
            $results = Article::orderBy("id", "DESC")->paginate(15);
        }
        return view('admin.articles', ['results' => $results, 'retailerId' => $retailerId]);
    }

    function payment($retailerId = null) {
        if (!empty($retailerId)) {
            $results = Tapupbalance::where(['userId' => $retailerId])->orderBy("created_at", "DESC")->paginate(15);
        } else {
            $results = Tapupbalance::orderBy("id", "DESC")->paginate(15);
        }
        return view('admin.payment', ['results' => $results, 'retailerId' => $retailerId]);
    }

    function pages() {
        $results = Page::paginate(15);
        return view('admin.pages', ['results' => $results]);
    }

    function pageEdit(Request $request, $id) {
        if ($request->isMethod("POST")) {
            $requestData = $request->all();
            $validator = Validator::make($request->all(), [
                        'title' => 'required|Min:5',
                        'content' => 'required|Min:10'
            ]);
            if ($validator->fails()) {
                Session::flash('error', "Oops! it's seems, something isn't validate in below form, please check carefully.");
                return redirect("admin/pageEdit/$id")->withErrors($validator)->withInput();
            } else {
                extract($requestData);
                unset($requestData['_token']);
                $requestData['status'] = empty($requestData['status']) ? 0 : 1;
                Page::where(["id" => $id])->update($requestData);
                Session::flash('success', "Your page content has been updated successfully.");
                return redirect()->route('apages');
            }
        }
        $row = Page::where(['id' => $id])->first();
        return view('admin.pageEdit', ['row' => $row]);
    }

    function changePassword(Request $request) {
        if ($request->isMethod("POST")) {
            $requestData = $request->all();
            $validator = Validator::make($request->all(), [
                        'oldPassword' => 'required|Min:5',
                        'password' => 'required|Min:5',
                        'confirmationPassword' => 'required|Min:5|same:password'
            ]);
            if ($validator->fails()) {
                Session::flash('error', "Oops! it's seems, something isn't validate in below form, please check carefully.");
                return redirect()->route('acp')->withErrors($validator)->withInput();
            } else {
                extract($requestData);
                if (Auth::attempt(['username' => 'heartbeat', 'password' => $oldPassword, 'type' => '143', 'status' => 0])) {
                    $adminUser = User::where(['type' => '143', 'status' => 0, 'username' => 'heartbeat']);
                    $adminUser->update(['password' => bcrypt($password)]);
                    Session::flash('success', "Your password has been changed successfully.");
                    return redirect()->route('acp');
                } else {
                    Session::flash('error', "Oops! it's seems, you are not admin, old password was wrong.");
                    return redirect()->route('acp');
                }
            }
        }
        return view('admin.cp');
    }

    function enbleDisableGame($table, $id, $status) {
        Session::flash('success', "Your information has been changed successfully.");
        DB::table($table)->where('id', $id)->update(["status" => $status]);
        return redirect(url()->previous());
    }

    function deleteGame($table, $id) {
        Session::flash('success', "Your data has been deleted successfully.");
        DB::table($table)->where('id', $id)->delete();
        return redirect(url()->previous());
    }

}
