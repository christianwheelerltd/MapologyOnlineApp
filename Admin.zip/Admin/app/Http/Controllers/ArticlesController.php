<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Article;
use Auth;
use Session;
use DB;
use Config;
use Carbon\Carbon;

class ArticlesController extends Controller {

    function __construct() {
        $this->picPath = Config::get('consts.articlePicPath');
    }

    function addArticle(Request $request) {
        if ($request->isMethod("POST")) {
            $requestData = $request->all();
            $validator = Validator::make($request->all(), [
                        'locationUser' => 'required',
                        'startDate' => 'required',
                        'endDate' => 'required|after:startDate',
                        'title' => 'required|min:5|max:60',
                        'content' => 'required|min:10|max:140',
                        'coverImage' => 'required'
            ]);
            if (!empty($requestData['locationUser'])) {
                $validator->after(function ($validator) use ($requestData) {
                    if (!$this->lookUpTheSky($requestData['locationUser'])) {
                        $validator->errors()->add('locationUser', 'This address is not sufficient for search this article in the APP. Please add street, city or state name.');
                    }
                });
            }

            if ($validator->fails()) {
                Session::flash('error', "Oops! it's seems, something isn't validate in below form, please check carefully.");
                return redirect('addArticle')->withErrors($validator)->withInput();
            } else {
                $retailerId = Auth::id();
                if (!empty($requestData['coverImage'])) {
                    $picName = saveProfilePic($requestData['coverImage'], $this->picPath);
                } else {
                    $picName = "";
                }
                $geCodeArr = $this->lookUpTheSky($requestData['locationUser']);
                $requestData = array_merge($requestData, [
                    'retailerId' => $retailerId,
                    'slug' => str_slug($requestData['title']),
                    'status' => 0,
                    'coverImage' => $picName,
                    'lati' => $geCodeArr['latitude'],
                    'longi' => $geCodeArr['longitude'],
                    'planId' => 0,
                    'created_at' => Carbon::now()
                ]);
                $art = Article::insertGetId($requestData);
                return redirect("plans/" . base64_encode($art));
            }
        }
        return view('articles.add');
    }

    function editArticle(Request $request, $id) {
        $retailerId = Auth::id();
        $artRows = Article::where(["retailerId" => $retailerId, 'id' => $id]);

        if ($request->isMethod("POST")) {
            $requestData = $request->all();
            $validator = Validator::make($request->all(), [
                        'locationUser' => 'required',
                        'title' => 'required|min:5|max:60',
                        'content' => 'required|min:10|max:140'
            ]);
            if (!empty($requestData['locationUser'])) {
                $validator->after(function ($validator) use ($requestData) {
                    if (!$this->lookUpTheSky($requestData['locationUser'])) {
                        $validator->errors()->add('locationUser', 'This address is not sufficient for search this article in the APP. Please add street, city or state name.');
                    }
                });
            }
            if ($validator->fails()) {
                Session::flash('error', "Oops! it's seems, something isn't validate in below form, please check carefully.");
                return redirect("editArticle/$id")->withErrors($validator)->withInput();
            } else {

                if ($artRows->count() <= 0) {
                    Session::flash('error', "Hey!! You are not authorised for this action.");
                    return redirect("editArticle/$id")->withErrors($validator)->withInput();
                }
                $artObj = $artRows->select("coverImage","endDate as ed","amount","planId")->first();
                if (strtotime($artObj->ed) <= time()) {
                    Session::flash('error', "This Article date has been overed, you can't pubish this. Please add new article.");
                    return redirect("editArticle/$id")->withErrors($validator)->withInput();
                }
                if (empty($artObj->amount) || empty($artObj->planId) || $artObj->amount == 0 || $artObj->planId == 0) {
                    Session::flash('error', "Payment was not confirmed for this article, Please confirm your payment.");
                    return redirect("plans/".  base64_encode($id))->withErrors($validator)->withInput();
                }
                if (!empty($requestData['coverImage'])) {
                    @unlink($this->picPath . $artObj->coverImage);
                    $picName = saveProfilePic($requestData['coverImage'], $this->picPath);
                } else {
                    $picName = $artObj->coverImage;
                }
                $geCodeArr = $this->lookUpTheSky($requestData['locationUser']);
                if (!empty($requestData['startDate'])) {
                    unset($requestData['startDate']);
                }
                if (!empty($requestData['endDate'])) {
                    unset($requestData['endDate']);
                }
                $requestData = array_merge($requestData, [
                    'retailerId' => $retailerId,
                    'slug' => str_slug($requestData['title']),
                    'coverImage' => $picName,
                    'lati' => $geCodeArr['latitude'],
                    'longi' => $geCodeArr['longitude'],
                    'status' => true,
                    'updated_at' => Carbon::now()
                ]);
                $artObj->where(['id' => $id])->update($requestData);
                Session::flash('success', 'Your article has been updated successfully.');
                return redirect('home');
            }
        }
        if ($artRows->count() <= 0) {
            Session::flash('error', "Hey!! You are not authorised for this action.");
            return redirect("home");
        }
        return view('articles.edit', ['row' => $artRows->first(), 'id' => $id]);
    }

    function disableArticle($id) {
        $retailerId = Auth::id();
        $isExist = Article::where(['retailerId' => $retailerId, 'id' => $id]);
        if ($isExist->count()) {
            $isExist->update(['status' => 0]);
            Session::flash('success', 'Your article has been disabled successfully.');
            return redirect('home');
        }
        Session::flash('error', 'Your are not authorised for this action.');
        return redirect('home');
    }

    function deleteArticle($id) {
        $retailerId = Auth::id();
        $isExist = Article::where(['retailerId' => $retailerId, 'id' => $id]);
        if ($isExist->count()) {
            @unlink($this->picPath . $isExist->first()->coverImage);
            $isExist->delete();
            Session::flash('success', 'Your article has been deleted successfully.');
            return redirect('home');
        }
        Session::flash('error', 'Your are not authorised for this action.');
        return redirect('home');
    }

    function lookUpTheSky($string) {
        $string = str_replace(" ", "+", urlencode($string));
        $details_url = "https://maps.googleapis.com/maps/api/geocode/json?address=" . $string . "&sensor=false";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $details_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $response = json_decode(curl_exec($ch), true);
        // If Status Code is ZERO_RESULTS, OVER_QUERY_LIMIT, REQUEST_DENIED or INVALID_REQUEST
        if ($response['status'] != 'OK') {
            DB::table('apilogs')->insert(['api' => 'geocode', 'apiLog' => serialize($response)]);
            return null;
        }
        $geometry = $response['results'][0]['geometry'];
        $array = array(
            'latitude' => $geometry['location']['lat'],
            'longitude' => $geometry['location']['lng'],
            'location_type' => $geometry['location_type'],
        );
        return $array;
    }

    function statusArticles() {
        Article::where(['status' => TRUE])->whereDate('endDate', '<=', Carbon::now())->chunk(150, function($results) {
            foreach ($results as $row):
                Article::where(['id' => $row->id])->update(['status' => 0]);
            endforeach;
            return true;
        });
    }

    function clearCronLogFileOnceInDay() {
        file_put_contents(base_path() . "/cronlog.txt", "");
        return true;
    }

}
