<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use App\Article;
use Carbon\Carbon;
use App\FollowArt;

class ArtController extends Controller {

    function getById(Request $request) {
        $requestData = $request->json()->all();
        $validator = Validator::make($requestData['data'], [
                    'id' => 'required'
        ]);
        if ($validator->fails()) {
            $validator->errors()->add('status', 0);
            $err = array_combine($validator->errors()->keys(), $validator->errors()->all());
            return response()->json($err)->setEncodingOptions(JSON_NUMERIC_CHECK);
        } else {
            extract($requestData['data']);
            $articleRow = Article::where(['id' => $id])->first();
            $respArr = ['status' => 1, 'data' => $articleRow];
            return response()->json($respArr)->setEncodingOptions(JSON_NUMERIC_CHECK);
        }
    }

    function saveFollowArt(Request $request) {
        $requestData = $request->json()->all();
        $validator = Validator::make($requestData['data'], [
                    'articleId' => 'required'
        ]);
        if ($validator->fails()) {
            $validator->errors()->add('status', 0);
            $err = array_combine($validator->errors()->keys(), $validator->errors()->all());
            return response()->json($err)->setEncodingOptions(JSON_NUMERIC_CHECK);
        } else {
            unset($requestData['data']['token']);
            $row = FollowArt::create($requestData['data']);
            $respArr = ['status' => 1, 'data' => $row];
            return response()->json($respArr)->setEncodingOptions(JSON_NUMERIC_CHECK);
        }
    }

    function articleBySlug(Request $request) {
        $requestData = $request->json()->all();
        $category = "";
        if (!empty($requestData['data']['slug'])) {
            $valiArr = [
                'category' => 'required|in:fast-food,pub,coffee-shop,restaurant',
                'miles' => 'required'];
        } else {
            $valiArr = ['miles' => 'required'];
        }
        $validator = Validator::make($requestData['data'], $valiArr);
        if ($validator->fails()) {
            $validator->errors()->add('status', 0);
            $err = array_combine($validator->errors()->keys(), $validator->errors()->all());
            return response()->json($err)->setEncodingOptions(JSON_NUMERIC_CHECK);
        }

        extract($requestData['data']);
        $snwe = $this->bound($miles[1], $miles[2], $miles[0], "mi");
        $arr = [];
        $results = Article::select('id', 'title', 'coverImage', 'retailerId', 'lati', 'longi','category')
                        ->when($category, function($query) use ($category) {
                            return $query->whereIn('category', $category);
                        })
                        ->whereBetween('lati', [$snwe['S']['lat'], $snwe['N']['lat']])
                        ->whereBetween('longi', [$snwe['W']['lon'], $snwe['E']['lon']])
                        ->where(['status' => 1])->paginate(15);
        foreach ($results as $row):
            $arr[] = array_merge(
                    $row->toArray(), [
                'distance' => $row->distanceArt($userId, $row->lati, $row->longi, $miles),
                'followed' => $row->followedArt($userId)
                    ]
            );
        endforeach;
        $respArr = ['status' => 1, 'data' => $arr];
        return response()->json($respArr)->setEncodingOptions(JSON_NUMERIC_CHECK);
    }

    function bound($lat, $lon, $distance, $units = "mi") {
        return array("N" => $this->destination($lat, $lon, 0, $distance, $units),
            "E" => $this->destination($lat, $lon, 90, $distance, $units),
            "S" => $this->destination($lat, $lon, 180, $distance, $units),
            "W" => $this->destination($lat, $lon, 270, $distance, $units));
    }

    function distance($latA, $lonA, $latB, $lonB, $units = "mi") {
        $radius = strcasecmp($units, "km") ? 3963.19 : 6378.137;
        $rLatA = deg2rad($latA);
        $rLatB = deg2rad($latB);
        $rHalfDeltaLat = deg2rad(($latB - $latA) / 2);
        $rHalfDeltaLon = deg2rad(($lonB - $lonA) / 2);
        return 2 * $radius * asin(sqrt(pow(sin($rHalfDeltaLat), 2) +
                                cos($rLatA) * cos($rLatB) * pow(sin($rHalfDeltaLon), 2)));
    }

// calculate destination lat/lon given a starting point, bearing, and distance
    function destination($lat, $lon, $bearing, $distance, $units = "mi") {
        $radius = strcasecmp($units, "km") ? 3963.19 : 6378.137;
        $rLat = deg2rad($lat);
        $rLon = deg2rad($lon);
        $rBearing = deg2rad($bearing);
        $rAngDist = $distance / $radius;

        $rLatB = asin(sin($rLat) * cos($rAngDist) +
                cos($rLat) * sin($rAngDist) * cos($rBearing));
        $rLonB = $rLon + atan2(sin($rBearing) * sin($rAngDist) * cos($rLat), cos($rAngDist) - sin($rLat) * sin($rLatB));
        return array("lat" => rad2deg($rLatB), "lon" => rad2deg($rLonB));
    }

}
