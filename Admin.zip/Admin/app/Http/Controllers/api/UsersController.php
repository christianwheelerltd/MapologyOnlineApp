<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;
use Validator;
use App\User;
use Auth;
use Mail;

class UsersController extends Controller {

    public $ta;

    function __construct() {
        $this->ta = DB::table('users');
    }

    function login(Request $request) {
        $requestData = $request->json()->all();
        $validator = Validator::make($requestData['data'], [
                    'email' => 'required|min:5|max:150',
                    'password' => 'required|min:6|max:150',
                    'deviceToken' => 'required'
        ]);
        if ($validator->fails()) {
            $validator->errors()->add('status', 0);
            $err = array_combine($validator->errors()->keys(), $validator->errors()->all());
            return response()->json($err)->setEncodingOptions(JSON_NUMERIC_CHECK);
        } else {
            extract($requestData['data']);
            if (Auth::once(['email' => $email, 'password' => $password, 'type' => 1])) {
                $userRow = Auth::user();
                User::where('id', $userRow->id)->update(['deviceToken' => $deviceToken]);
                $respArr = ['status' => 1, 'userId' => $userRow->id, 'token' => $userRow->remember_token];
                return response()->json($respArr)->setEncodingOptions(JSON_NUMERIC_CHECK);
            } else {
                return response()->json(['status' => 0, 'message' => 'invalid credentials.'])->setEncodingOptions(JSON_NUMERIC_CHECK);
            }
        }
    }

    function register(Request $request) {
        $requestData = $request->json()->all();
        if (!empty($requestData['data']['isSocial'])) {
            $validator = Validator::make($requestData['data'], [
                        'name' => 'required|min:2|max:150',
                        'socialId' => 'required|min:5|max:150',
                        'socialType' => 'required|in:facebook,twitter,google',
                        'deviceToken' => 'required',
            ]);
        } else {
            $validator = Validator::make($requestData['data'], [
                        'name' => 'required|min:2|max:150',
                        'surname' => 'required|min:2|max:100',
                        'email' => 'required|min:5|max:100|unique:users',
                        'deviceToken' => 'required',
                        'password' => 'required'
            ]);
        }
        if ($validator->fails()) {
            $validator->errors()->add('status', 0);
            $err = array_combine($validator->errors()->keys(), $validator->errors()->all());
            return response()->json($err)->setEncodingOptions(JSON_NUMERIC_CHECK);
        } else {
            /* Check If already Exist */
            if (!empty($requestData['data']['isSocial'])) {
                $wheres = ['socialId' => $requestData['data']['socialId'], 'type' => 1, 'socialType' => $requestData['data']['socialType']];
            } else {
                $wheres = ['email' => $requestData['data']['email'], 'type' => 1];
            }
            $userCon = $this->ta->where($wheres);
            if ($userCon->count()) {
                $userRow = $userCon->first();
                $respArr = ['status' => 1, 'userId' => $userRow->id, 'token' => $userRow->remember_token];
                return response()->json($respArr)->setEncodingOptions(JSON_NUMERIC_CHECK);
            } else {
                if (!empty($requestData['data']['isSocial'])) {
                    $pwd = str_random(6);
                } else {
                    $pwd = $requestData['data']['password'];
                }
                $extraArr = ['joinedBy' => 'app', 'password' => bcrypt($pwd), 'chabbi' => $pwd, 'remember_token' => str_random(30)];
                $newArr = array_merge($requestData['data'], $extraArr);
                $userRow = User::create($newArr);
                $respArr = ['status' => 1, 'userId' => $userRow->id, 'token' => $userRow->remember_token];
                return response()->json($respArr)->setEncodingOptions(JSON_NUMERIC_CHECK);
            }
        }
    }

    function forgotPassword(Request $request) {
        $requestData = $request->json()->all();
        $validator = Validator::make($requestData['data'], [
                    'email' => 'required|min:5|max:150'
        ]);
        if ($validator->fails()) {
            $validator->errors()->add('status', 0);
            $err = array_combine($validator->errors()->keys(), $validator->errors()->all());
            return response()->json($err)->setEncodingOptions(JSON_NUMERIC_CHECK);
        } else {
            extract($requestData['data']);
            $ailUser = $this->ta->where(['email' => $email]);
            if ($ailUser->count() == 1) {
                $userRow = $ailUser->first();

                Mail::send('emails.universal', ['row' => $userRow], function ($message) use ($email) {
                    //$message->from('testing2012user@gmail.com', 'Mapology');

                    $message->to($email);
                    $message->subject('Mapology: Forgot Password Link');
                });
                $respArr = ['status' => 1, 'message' => "A link has been sent in your email. Please check."];
                return response()->json($respArr)->setEncodingOptions(JSON_NUMERIC_CHECK);
            } else {
                $respArr = ['status' => 0, 'message' => "This email doesn't exists."];
                return response()->json($respArr)->setEncodingOptions(JSON_NUMERIC_CHECK);
            }
        }
    }

    function locationUpdate(Request $request) {
        $requestData = $request->all();
        $validator = Validator::make($requestData['data'], [
                    'lati' => 'required',
                    'longi' => 'required'
        ]);
        if ($validator->fails()) {
            $validator->errors()->add('status', 0);
            $err = array_combine($validator->errors()->keys(), $validator->errors()->all());
            return response()->json($err)->setEncodingOptions(JSON_NUMERIC_CHECK);
        } else {
            extract($requestData['data']);
            User::where(['id' => $userId])->update(['lati' => $lati, 'longi' => $longi]);
            return response()->json(['status' => 1, 'message' => 'Location has been updated successfully.'])->setEncodingOptions(JSON_NUMERIC_CHECK);
        }
    }

}
