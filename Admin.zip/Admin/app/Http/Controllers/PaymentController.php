<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Session;
use App\Article;
use App\User;
use Auth;
use Carbon\Carbon;
use Omnipay\Omnipay;
use Omnipay\Common\CreditCard;
//use Omnipay\PayPal\Message\ProAuthorizeRequest;
//use Omnipay\PayPal\RestGateway;
use DB;
use App\Tapupbalance;

class PaymentController extends Controller {

    private $paypalCredentials;
    private $apiLog;

    function __construct() {
        $this->paypalCredentials = ['username' => 'khushwinder_api1.34interactive.com',
            'password' => 'SDK2EHJ2J97ABKB3',
            'signature' => 'AFcWxV21C7fd0v3bYYYRCpSSRl31AsJWhhyx5j8imN8dF81RAzIfyJeN',
            'testMode' => true, //'payment.paypal_testmode',
            'landingPage' => array('billing', 'login')
        ];
        $this->apiLog = DB::table('apilogs');
    }

    function selectPlans(Request $request, $id) {
        $currentBalance = userRow()->balance;
        if ($request->isMethod("POST")) {
            $requestData = $request->all();
            $messsages = array(
                'planId.required' => 'Please on click to select any one plan.',
                'amount.required' => 'Please on click to select any one plan.'
            );
            $rules = array(
                'planId' => 'required',
                'amount' => 'required',
            );

            $validator = Validator::make($requestData, $rules, $messsages);
            $validator->after(function ($validator) use ($requestData, $currentBalance) {
                if ($currentBalance < $requestData['amount']) {
                    $validator->errors()->add('amounts', "It's seems, your balance is not sufficient for this article plan. Please Tap Up Your Balance.");
                }
            });

            if ($validator->fails()) {
                Session::flash('error', "Oops! it's seems, something isn't validate in below plans, please check carefully.");
                return redirect('plans/' . $id)->withErrors($validator)->withInput();
            } else {

                if ($currentBalance >= $requestData['amount']) {
                    unset($requestData['_token']);
                    $art = Article::where(['retailerId' => Auth::id(), 'id' => base64_decode($id)]);
                    if ($art->count() == 1) {
                        if (in_array($requestData['planId'], [1, 2])) {
                            $addDays = ($requestData['planId'] == 1) ? 7 : 30;
                            $artRow = $art->select('startDate as sd', 'amount')->first();
                            $dt = new Carbon($artRow->sd);
                            $requestData['endDate'] = $dt->addDays($addDays);
                            $requestData['status'] = 1;
                            $art->update($requestData);
                            User::where(['id' => Auth::id()])->update(['balance' => (int) $currentBalance - (int) $requestData['amount']]);
                            $this->creditDebit(['userId' => Auth::id(), 'status' => "debited", 'paymentMethod' => 'direct-cut', 'amount' => $requestData['amount']]);
                        }
                        Session::flash('success', 'Your article has been added successfully.');
                        return redirect("home");
                    } else {
                        return redirect("https://google.com?q=facebook.com/heartbeatsingh");
                    }
                } else {
                    Session::flash('error', "Oops! it's seems, your balance isn't sufficient for make live this article. Please tap up your balance.");
                    return redirect("payment");
                }
            }
        }
        return View('payment/plans', ['id' => $id ? $id : 0, 'currentBalance' => $currentBalance]);
    }

    function payment(Request $request, $id = null) {
        if ($request->isMethod("POST")) {
            $requestData = $request->all();
            $validator = Validator::make($request->all(), [
                        'firstName' => 'required|min:2',
                        'lastName' => 'required|min:1',
                        'cardNo' => 'required|min:12|max:16',
                        'cardExpMonth' => 'required',
                        'cardExpYear' => 'required',
                        'cardCvv' => 'required|min:3|max:3',
                        'amount' => 'required'
            ]);
            if ($validator->fails()) {
                $validator->errors()->add('err', "failed");
                $err = array_combine($validator->errors()->keys(), $validator->errors()->all());
                return response()->json($err);
            } else {
                $paymentResponse = $this->paymentRequest($requestData, $id);
                if (!empty($paymentResponse['ACK']) && strtolower($paymentResponse['ACK']) == "success") {
                    $user = User::where(["id" => Auth::id()]);
                    $userPreviousBalance = $user->first()->balance;
                    $user->update(["balance" => $userPreviousBalance += $requestData["amount"]]);
                    $this->creditDebit(['userId' => Auth::id(), 'status' => "credited", 'paymentMethod' => 'credit-card', 'amount' => $requestData["amount"]]);
                    if (empty($id)) {
                        Session::flash('success', 'Awesome! Your payment process has been completed successfully.');
                    } else {
                        Session::flash('success', 'Awesome! Your payment process has been completed successfully. Please select plan and continue.');
                    }
                    return response()->json(['payment' => true, 'status' => true, 'err' => ['status' => false]]);
                } else {
                    return response()->json(['payment' => false, 'status' => false, 'err' => $paymentResponse]);
                }
            }
        }
        return View('payment/payment', ['articleId' => $id]);
    }

    function paymentRequest($requestData, $articleId = null) {
        $gateway = Omnipay::create('PayPal_Express');
        $gateway->initialize($this->paypalCredentials);
        //$settings = $gateway->getDefaultParameters();
        extract($requestData);
        $parameters = [
            'firstName' => $firstName,
            'lastName' => $lastName,
            'number' => $cardNo,
            'cvv' => $cardCvv,
            //'expiryMonth' => $cardExpMonth,
            'expiryMonth' => '10',
            'expiryYear' => $cardExpYear
        ];

        $card = new CreditCard($parameters);
        $err = [];
        $response = $gateway->authorize(array('amount' => number_format($amount, 2), 'returnUrl' => url("paymentComplete/paypalCreditCard/$articleId"), 'cancelUrl' => url("paymentCancel/paypalCreditCard/$articleId"), 'card' => $card))->send();
        $tokenId = $response->getTransactionReference();
        return $resp = $response->getData();
        if (!empty($resp['ACK']) && strtolower($resp['ACK']) == "success") {
            $response = $response->getData();
            $capture = $gateway->capture(array(
                'transactionReference' => $tokenId,
                'amount' => number_format($amount, 2)
            ));
            $response = $capture->send();
            $resp2 = $response->getData();
            if (!empty($resp2['ACK']) && strtolower($resp2['ACK']) == "success") {
                $this->addPaypalCCLog($resp, "Success");
                return $resp2;
            } else {
                $this->addPaypalCCLog($resp, "Failed");
                $err['status'] = !empty($resp2["L_LONGMESSAGE0"]) ? $resp2["L_LONGMESSAGE0"] : "";
                return $err;
            }
        }
        $this->addPaypalCCLog($resp, "Failed");
        return $err['status'] = "failed";
    }

    function addPaypalCCLog($resp, $status) {
        $this->apiLog->insert(['api' => 'Credit Card Payment', 'userId' => Auth::id(), 'status' => $status, 'apiLog' => serialize($resp)]);
        return (strtolower($status) == "failed") ? false : true;
    }

    function creditDebit($arr) {
        return Tapupbalance::create($arr);
    }

    function paymentComplete(Request $request, $payMethod = null, $articleId = null) {
        $requestData = $request->all();
        $userPreviousBalance = 0;
        $gateway = Omnipay::create('PayPal_Express');
        $gateway->initialize($this->paypalCredentials);
        extract($requestData);
        $apiRaw = $this->apiLog->where(['token' => $token, 'status' => 'Pending']);
        $apiRow = $apiRaw->orderBy('id', 'desc')->first();
        $completePurchase = $gateway->completePurchase(array(
            'transactionReference' => $apiRow->token,
            'payerId' => $PayerID,
            "amount" => number_format($apiRow->amount, 2)
        ));
        $response = $completePurchase->send();
        $resp = $response->getData();
        if (!empty($resp['ACK']) && strtolower($resp['ACK']) == 'success' || strtolower($resp['ACK']) == 'successwithwarning') {
            $user = User::where(["id" => Auth::id()]);
            $userRow = $user->first();
            $userPreviousBalance = !empty($userRow->balance) ? $userRow->balance : 0;
            $user->update(["balance" => $userPreviousBalance += $apiRow->amount]);
            $apiRaw->update(['apiLog' => serialize($resp), 'status' => 'Success']);
            $this->creditDebit(['userId' => Auth::id(), 'status' => "credited", 'paymentMethod' => 'paypal-rest', 'amount' => $apiRow->amount]);
            if (!empty($articleId)) {
                Session::flash('success', 'Awesome! Your payment process has been completed successfully. Please select plan and continue.');
                return redirect("plans/$articleId");
            } else {
                Session::flash('success', 'Awesome! Your payment process has been completed successfully.');
                return redirect("home");
            }
        } else {
            $this->apiLog->insert(['api' => 'Paypal Rest API Payment', 'userId' => Auth::id(), 'status' => "Failed", 'apiLog' => serialize($resp)]);
            Session::flash('error', "Oops! Due to some technical resion, your payment process has been failed. Please try again.");
            if (!empty($articleId)) {
                return redirect("plans/$articleId");
            } else {
                return redirect("home");
            }
        }
    }

    function paymentCancel(Request $request, $payMethod, $articleId = null) {
        $requestData = $request->all();
        extract($requestData);
        if (!empty($payMethod) && $payMethod == "paypalRest") {
            $this->apiLog->insert(['api' => 'Cancelled Paypal Rest API Payment', 'userId' => Auth::id(), 'status' => "Failed", 'token' => $token]);
            Session::flash('error', "Oops! Due to some technical resion, your payment process has been cancelled. Please try again.");
            return redirect("home");
        } else {
            
        }
    }

    function getSetRestPaypal(Request $request) {
        $requestData = $request->all();
        extract($requestData);
        $gateway = Omnipay::create('PayPal_Express');
        $gateway->initialize($this->paypalCredentials);
        $validator = Validator::make($request->all(), ['amounts' => 'required'], ["amounts.required" => "The amount field is required."]);
        if ($validator->fails()) {
            Session::flash('error', "Oops! it's seems, something isn't validate in below form, please check carefully.");
            return redirect('payment/' . $articleId)->withErrors($validator)->withInput();
        } else {
            $userRow = userRow();
            $desc = $userRow->name . "|" . $userRow->id . "|TapOfBalance|PaypalRest";
            $purchase = $gateway->purchase(array(
                'currency' => 'USD',
                'amount' => number_format($amounts, 2),
                'description' => $desc,
                'returnUrl' => url("paymentComplete/paypalRest/$articleId"),
                'cancelUrl' => url("paymentCancel/paypalRest/$articleId")
            ));
            $response = $purchase->send();
            $resp = $response->getData();
            $txnRef = $response->getTransactionReference();
            if ($response->isRedirect() && !empty($txnRef)) {
                $this->apiLog->insert(['amount' => $amounts, 'token' => $txnRef, 'api' => 'Paypal Rest API Payment', 'userId' => Auth::id(), 'status' => !empty($resp['ACK']) ? "Pending" : "Pending", 'apiLog' => serialize($resp)]);
                return $response->redirect();
            } else {
                $this->apiLog->insert(['api' => 'Paypal Rest API Payment', 'userId' => Auth::id(), 'status' => !empty($resp['ACK']) ? $resp['ACK'] : "Failed", 'apiLog' => serialize($resp)]);
                Session::flash('error', "Oops! Due to some technical resion, your payment process has been failed. Please try again.");
                return redirect("home");
            }
        }
    }

   

}
