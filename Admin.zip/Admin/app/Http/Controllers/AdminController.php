<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Session;
use Auth;

class AdminController extends Controller {

    function login(Request $request) {
        if ($request->isMethod("POST")) {
            $requestData = $request->all();
            $validator = Validator::make($request->all(), [
                        'email' => 'required',
                        'password' => 'required'
            ]);
            if ($validator->fails()) {
                Session::flash('error', "Oops! it's seems, something isn't validate in below form, please check carefully.");
                return redirect('admin')->withErrors($validator)->withInput();
            } else {
                extract($requestData);
                if (Auth::attempt(['email' => $email, 'password' => $password, 'type' => '143', 'status' => 0])) {
                    return redirect()->route('adashboard');
                } else {
                    Session::flash('error', "Invalid credentials, please check and try again.");
                    return redirect('admin')->withErrors($validator)->withInput();
                }
            }
        }
    }

}
