<?php

function saveProfilePic($img, $pPath = "consts.profilePicPath") {
    $imgType = substr($img, 11, strpos($img, ';') - 11);
    $img = str_replace(array('data:image/png;base64,', 'data:image/jpeg;base64,', 'data:image/jpg;base64,'), array('', '', ''), $img);
    $img = str_replace(' ', '+', $img);
    $dataImage = base64_decode($img);
    $picName = 'heartbeat-' . str_random(10) . '-' . "." . $imgType;
    $picPath = $pPath . $picName;
    if (!empty($dataImage)) {
        if (file_put_contents($picPath, $dataImage)) {
            return $picName;
        } else {
            return false;
        }
    }
}

function isAuthUser($userId = 0, $token = 'fb/heartbeatsingh') {
    return DB::table('users')->where(['id' => $userId, 'remember_token' => $token])->count();
}

function userRow() {
    return DB::table('users')->where(['id' => Auth::id()])->first();
}

function retailerActiveArts() {
    return DB::table('articles')->where(['retailerId' => Auth::id(), 'status' => 1])->count();
}

function retailerDesabledArts() {
    return DB::table('articles')->where(['retailerId' => Auth::id(), 'status' => 0])->count();
}

function retailerTotalArts() {
    return DB::table('articles')->where(['retailerId' => Auth::id()])->count();
}

function addArticleTimeSave() {
    $arr = [];
    $daysInMonth = cal_days_in_month(CAL_GREGORIAN, date('m'), date('Y'));
    foreach (range(0, $daysInMonth) as $dd):
        $arr['days'][] = $dd;
    endforeach;
    return $arr;
}

function getRetailers() {
    return DB::table('users')->where(['type' => 2])->get();
}
