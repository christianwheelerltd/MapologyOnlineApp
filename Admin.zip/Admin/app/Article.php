<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use DB;

class Article extends Model {

    protected $fillable = ['*'];
    protected $hidden = [];

    public function getStartDateAttribute() {
        $startDate = new Carbon($this->attributes['startDate']);
        $arr = [$startDate->format('d M'), $startDate->format('h A')];
        return $arr ? $arr : [];
    }

    public function getEndDateAttribute() {
        $endDate = new Carbon($this->attributes['endDate']);
        $arr = [$endDate->format('d M'), $endDate->format('h A')];
        return $arr ? $arr : [];
    }

    function followedArt($userId) {
        return $this->hasOne('App\FollowArt', 'articleId', 'id')->where(['userId' => $userId])->count();
    }

    function distanceArt($userId, $lati, $longi, $miles) {
        return round($this->yeDooriyan($lati, $longi, $miles[1], $miles[2]), 2);
    }

    function yeDooriyan($latA, $lonA, $latB, $lonB, $units = "mi") {
        $radius = strcasecmp($units, "km") ? 3963.19 : 6378.137;
        $rLatA = deg2rad($latA);
        $rLatB = deg2rad($latB);
        $rHalfDeltaLat = deg2rad(($latB - $latA) / 2);
        $rHalfDeltaLon = deg2rad(($lonB - $lonA) / 2);

        return 2 * $radius * asin(sqrt(pow(sin($rHalfDeltaLat), 2) +
                                cos($rLatA) * cos($rLatB) * pow(sin($rHalfDeltaLon), 2)));
    }

    function artOwner() {
        return $this->hasOne("App\User", "id", 'retailerId')->select("companyName");
    }

    function getArtChart() {
        $arts = Article::select(DB::raw("UNIX_TIMESTAMP(created_at)*1000 as artTime, COUNT(*) as ttlArt"))->whereRaw(DB::raw("amount IS NOT NULL"))->groupBy(DB::raw("DATE_FORMAT(created_at,'%y-%m-%d')"))->get();
        $artsArr = "";
        foreach ($arts as $art):
            //$artsArr .= "[".$art->artTime.",". $art->amount."],";
            $artsArr .= "[".$art->artTime.",".$art->ttlArt."],";
        endforeach;
        return substr($artsArr,0,-1);
    }
    
    function getArtByCat() {
        $arr['res'] = Article::where(['category'=>'restaurant'])->whereRaw(DB::raw("amount IS NOT NULL"))->count();
        $arr['pub'] = Article::where(['category'=>'pub'])->whereRaw(DB::raw("amount IS NOT NULL"))->count();
        $arr['fas'] = Article::where(['category'=>'fast-food'])->whereRaw(DB::raw("amount IS NOT NULL"))->count();
        $arr['cof'] = Article::where(['category'=>'coffee-shop'])->whereRaw(DB::raw("amount IS NOT NULL"))->count();
        $arr['all'] = Article::whereRaw(DB::raw("amount IS NOT NULL"))->count();
        return $arr;
    }

}
