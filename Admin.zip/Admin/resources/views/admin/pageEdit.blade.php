@extends('layouts.admin')
@section('bc','Edit Content')
@section('flag','Edit your page information')
@section('pagAct','activeMenu')
@section('content')

<section class="created">
    <div class="col-xs-12">
        @include('admin.adminMenu')
        <div class="col-sm-9 list_item pad-none">
            <div class="sign-up-wrap1">
                <div class="sign-up" style="padding: 0">
                    <h2 class="text-center">Edit Content</h2>
                    <form class="form-horizontal" method="POST" role="form">
                        {{ csrf_field() }}

                        <div class = "col-sm-12 name {{ $errors->has('title') ? ' has-error' : '' }}">
                            <input type="text" class="form-control" name="title" value="{{$row->title}}">
                            @if ($errors->has('title'))
                            <span class="help-block">
                                <strong>{{ $errors->first('title') }}</strong>
                            </span>
                            @endif
                        </div>

                        <div class = "col-sm-12 name">
                            <input readonly="readonly" type="text" class="form-control" name="slug" value="{{$row->slug}}">
                        </div>

                        <div class = "col-sm-12 name {{ $errors->has('content') ? ' has-error' : '' }}">
                            <textarea name="content" id="editor1" class="form-control">{{$row->content}}</textarea>
                            @if ($errors->has('content'))
                            <span class="help-block">
                                <strong>{{ $errors->first('content') }}</strong>
                            </span>
                            @endif
                        </div>

                        <div class = "col-sm-12 name">
                            <label class="checkbox-inline">
                                <input type="checkbox" class="" name="status" {{ $row->status == true ? 'checked="checked"' : '' }}>Activate
                            </label>

                        </div>

                        <div class = "col-sm-offset-2 col-sm-12 sign_in">
                            <button type = "submit" class = "btn btn-default">Update</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
</section>
<script type="text/javascript">
    CKEDITOR.replace('editor1', {
        language: 'en',
        uiColor: '#64B92D'
    });
</script>
@endsection