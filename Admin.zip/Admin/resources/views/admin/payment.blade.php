@extends('layouts.admin')
@section('bc','Payments Log')
@section('flag','All retailers payments log')
@section('payAct','activeMenu')
@section('content')

<section class="created">

    <div class="col-xs-12">
        @include('admin.adminMenu')
        <div class="col-sm-9 list_item pad-none">
            <div class="col-sm-12 row">
                <select class="drop-down" id="retailerIds" name="retailerId" style="margin: 0px;">
                    <option value="">Filter By Company Name</option>
                    @foreach(getRetailers() as $rets)
                    @if($retailerId == $rets->id)
                    <option value="{{ $rets->id }}" selected="selected">{{ $rets->companyName }}</option>
                    @else
                    <option value="{{ $rets->id }}">{{ $rets->companyName }}</option>
                    @endif
                    @endforeach
                </select>
            </div>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Company Name</th>
                        <th>Amount</th>
                        <th>Payment Method</th>
                        <th>Status</th>
                        
                    </tr>
                </thead>
                <tbody>
                    @if(!$results->isEmpty())
                        @foreach($results as $row)
                        <tr>
                            <th scope="row">{{ $row->id }}</th>
                            <td>{{ $row->paymentOwner->companyName }}</td>
                            <td>${{ number_format($row->amount,2) }}</td>
                            <td>{{ $row->paymentMethod }}</td>
                            <td><?php echo ($row->status == "debited") ? "<div class='label label-danger'>Debited</div>" : "<div class='label label-success'>Credited</div>"; ?></td>
                            
                        </tr>
                        @endforeach
                    @else
                    <tr>
                        <td scope="row" colspan="6" align="center">No records found</td>
                    </tr>
                    @endif
                </tbody>
            </table>
            <div class="col-sm-12 text-right">{{ $results->links() }}</div>
        </div>
</section>
<script type="text/javascript">
    $(document).on('change', '#retailerIds', function () {
        if (!$(this).val().length) {
            window.location.href = "{{ route('apayments') }}";
        } else {
            window.location.href = "{{ route('apayments') }}" + "/" + $(this).val();
        }
    })
</script>

@endsection