<?php
$isSeg = Request::segment(2);
$breadCrumb = ($isSeg == "users") ? "Users" : "Retailers";
$flag = ($isSeg == "users") ? "Manage Users" : "Manage Retailers";
$actMenu = ($isSeg == "users") ? "usrAct" : "retAct";
?>
@extends('layouts.admin')
@section('bc',$breadCrumb)
@section('flag',$flag)
@section($actMenu,'activeMenu')
@section('content')

<section class="created">
    <div class="col-xs-12">
        @include('admin.adminMenu')
        <div class="col-sm-9 list_item pad-none">
            <table class="table table-hover">
                <thead>
                    @if($isSeg == "users")
                    <tr>
                        <th>ID</th>
                        <th>Cover Image</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($results as $row)
                    <tr>
                        <th scope="row">{{ $row->id }}</th>
                        <td><img class="img-thumbnail" src="{{ $row->coverImage != "" ? url(Config::get("consts.profilePicPath").$row->coverImage) : url("public/images/du.jpg") }}" width="80"></td>
                        <td>{{ $row->name." ".$row->surname }}</td>
                        <td>{{ $row->email }}</td>
                        <td><?php echo ($row->status == true) ? "<div class='label label-success'>Activated</div>" : "<div class='label label-danger'>Deactivated</div>"; ?></td>
                        <td>
                            <a href="javascript:void(0)" title="Click to Enable/Disable" onclick="goDisableEnable({{$row->id}},{{ $row->status == true ? 0 : 1 }})"><i class="fa fa-circle" style="color:{{ $row->status == true ? "green" : "red" }};font-size:18px"></i></a> 
                            <a href="javascript:void(0)" title="Click to Delete" onclick="goDelete({{$row->id}})"><i class="fa fa-trash" style="color: #C9302C;font-size:18px"></i></a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>

                @else

                <tr>
                    <th>ID</th>
                    <th>Cover Image</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Available Money</th>
                    <th>Spent Money</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    @foreach($results as $row)
                    <tr>
                        <th scope="row">{{ $row->id }}</th>
                        <td><img class="img-thumbnail" src="{{ $row->coverImage != "" ? url(Config::get("consts.profilePicPath").$row->coverImage) : url("public/images/du.jpg") }}" width="80"></td>
                        <td>{{ $row->companyName }}</td>
                        <td>{{ $row->email }}</td>                       
                        <td><span class='label label-info'>${{ number_format($row->balance,2) }}</span></td>
                        <td><span class='label label-danger'>${{ number_format($row->spentMoney(),2) }}</span></td>
                        <td><?php echo ($row->status == true) ? "<div class='label label-success'>Activated</div>" : "<div class='label label-danger'>Deactivated</div>"; ?></td>
                        <td>
                            <a href="javascript:void(0)" title="Click to Enable/Disable" onclick="goDisableEnable({{$row->id}},{{ $row->status == true ? 0 : 1 }})"><i class="fa fa-circle" style="color:{{ $row->status == true ? "green" : "red" }};font-size:18px"></i></a>                            
                        </td>
                    </tr>
                    @endforeach
                </tbody>

                @endif

            </table>
            <div class="col-sm-12 text-right">{{ $results->links() }}</div>
        </div>
</section>
<script type="text/javascript">
            function goDisableEnable(id, status) {
            var msgIs = (status == 0) ? "Disable" : "Enable";
                    swal({
                    title: "User " + msgIs,
                            text: "Please confirm, you want to " + msgIs + " this user?",
                            type: "info",
                            showCancelButton: true,
                            closeOnConfirm: false,
                            showLoaderOnConfirm: true,
                    }, function () {
                    setTimeout(function () {
                    window.location.href = "{{url('admin/enbleDisableGame')}}" + "/users/" + id + "/" + status;
                    }, 2000);
                    });
            }

    function goDelete(id) {
    swal({
    title: "User Delete",
            text: "Please confirm, you want to delete this user?",
            type: "error",
            showCancelButton: true,
            closeOnConfirm: false,
            showLoaderOnConfirm: true,
    },
            function () {
            setTimeout(function () {
            window.location.href = "{{url('admin/deleteGame')}}" + "/users/" + id;
            }, 2000);
            });
    }
</script>

@endsection