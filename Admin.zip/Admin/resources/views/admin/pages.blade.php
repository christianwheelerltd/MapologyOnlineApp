@extends('layouts.admin')
@section('bc','Pages')
@section('flag','Manage Your Content')
@section('pagAct','activeMenu')
@section('content')

<section class="created">
    <div class="col-xs-12">
        @include('admin.adminMenu')
        <div class="col-sm-9 list_item pad-none">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>                        
                        <th>Title</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($results as $row)
                    <tr>
                        <th scope="row">{{ $row->id }}</th>
                        <td>{{ $row->title }}</td>
                        <td cl><?php echo ($row->status == true) ? "<div class='label label-success'>Published</div>" : "<div class='label label-danger'>UnPublished</div>"; ?></td>
                        <td>
                            <a href="{{ url("admin/pageEdit/$row->id") }}"><i class="fa fa-edit" style="color:#286090;font-size:18px"></i></a> 
                            
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="col-sm-12 text-right">{{ $results->links() }}</div>
        </div>
</section>
@endsection