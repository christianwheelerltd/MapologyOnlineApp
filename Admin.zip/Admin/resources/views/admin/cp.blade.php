@extends('layouts.admin')
@section('bc','Change Password')
@section('flag','Change Password')
@section('cpAct','activeMenu')
@section('content')

<section class="created">
    <div class="col-xs-12">
        @include('admin.adminMenu')
        <div class="col-sm-9 list_item pad-none">
            <div class="sign-up-wrap1">
                <div class="sign-up" style="padding: 0">
                    <h2 class="text-center">Change Password</h2>
                    <form class="form-horizontal" method="POST" role="form">
                        {{ csrf_field() }}

                        <div class = "col-sm-12 name{{ $errors->has('oldPassword') ? ' has-error' : '' }}">
                            <input type="password" class="form-control" name="oldPassword" placeholder="Old Password" >
                            @if ($errors->has('oldPassword'))
                            <span class="help-block">
                                <strong>{{ $errors->first('oldPassword') }}</strong>
                            </span>
                            @endif
                        </div>

                        <div class = "col-sm-12 name{{ $errors->has('password') ? ' has-error' : '' }}">
                            <input type="password" class="form-control" name="password" placeholder="New Password" >
                            @if ($errors->has('password'))
                            <span class="help-block">
                                <strong>{{ $errors->first('password') }}</strong>
                            </span>
                            @endif
                        </div>

                        <div class = "col-sm-12 name{{ $errors->has('confirmationPassword') ? ' has-error' : '' }}">
                            <input type="password" class="form-control"  name="confirmationPassword" placeholder="Confirm Password" >
                            @if ($errors->has('confirmationPassword'))
                            <span class="help-block">
                                <strong>{{ $errors->first('confirmationPassword') }}</strong>
                            </span>
                            @endif
                        </div>

                        <div class = "col-sm-offset-2 col-sm-12 sign_in">
                            <button type = "submit" class = "btn btn-default">Submit</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
</section>
@endsection