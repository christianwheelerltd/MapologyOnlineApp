<div class="col-sm-3 right-row">

    <div class="col-xs-12 pad-none balance">
        <ul>
            <li><a href="{{ route('adashboard') }}" class="@yield('dbAct')"><i class="fa fa-home" style="color:seagreen"></i> Dashboard </a></li>
            <li><a href="{{ route('aretailers') }}/2" class="@yield('retAct')"><i class="fa fa-users" style="color:teal"></i> Retailers</a></li>
            <li><a href="{{ route('ausers') }}/1" class="@yield('usrAct')"><i class="fa fa-user" style="color:tomato"></i> Users</a></li>
            <li><a href="{{ route('aarticles') }}" class="@yield('artAct')"><i class="fa fa-leaf" style="color:green"></i> Articles</a></li>
            <li><a href="{{ route('apayments') }}" class="@yield('payAct')"><i class="fa fa-money" style="color:violet"></i> Payments</a></li>
            <li><a href="{{ route('apages') }}" class="@yield('pagAct')"><i class="fa fa-book" style="color:steelblue"></i> Pages</a></li>
            <li><a href="{{ route('acp') }}" class="@yield('cpAct')"><i class="fa fa-key" style="color:sienna"></i> Change Password</a></li>
            <li><a href="#"><i class="fa fa-lock" style="color:red"></i> Logout</a></li>
        </ul>
    </div>
</div>
