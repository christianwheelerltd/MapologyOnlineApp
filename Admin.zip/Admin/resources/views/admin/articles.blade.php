@extends('layouts.admin')
@section('bc','Retailer Articles')
@section('flag','Filter any retailer articles')
@section('artAct','activeMenu')
@section('content')

<section class="created">
    <div class="col-xs-12">
        @include('admin.adminMenu')
        <div class="col-sm-9 list_item pad-none">
            <div class="col-sm-12 row">
                <select class="drop-down" id="retailerIds" name="retailerId" style="margin: 0px;">
                    <option value="">Filter By Company Name</option>
                    @foreach(getRetailers() as $rets)
                    @if($retailerId == $rets->id)
                    <option value="{{ $rets->id }}" selected="selected">{{ $rets->companyName }}</option>
                    @else
                    <option value="{{ $rets->id }}">{{ $rets->companyName }}</option>
                    @endif
                    @endforeach
                </select>
            </div>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>                        
                        <th>Cover Image</th>
                        <th>Company Name</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @if(!$results->isEmpty())
                    @foreach($results as $row)
                    <tr>
                        <th scope="row">{{ $row->id }}</th>
                        <td><img class="img-thumbnail" src="{{ $row->coverImage != "" ? url(Config::get("consts.articlePicPath").$row->coverImage) : url("public/images/du.jpg") }}" width="80"></td>
                        <td>{{ $row->artOwner->companyName }}</td>
                        <td>{{ $row->title }}</td>
                        <td>{{ $row->category == null ? "all" : $row->category }}</td>
                        <td><span class='label label-info'>${{ number_format($row->amount,2) }}</span></td>
                        <td><?php echo ($row->status == true) ? "<div class='label label-success'>Published</div>" : "<div class='label label-danger'>Unpublished</div>"; ?></td>
                        <td>
                            <a href="javascript:void(0)" title="Click to Enable/Disable" onclick="goDisableEnable({{$row->id}},{{ $row->status == true ? 0 : 1 }})"><i class="fa fa-circle" style="color:{{ $row->status == true ? "green" : "red" }};font-size:18px"></i></a> 
                            <a href="javascript:void(0)" title="Click to Delete" onclick="goDelete({{$row->id}})"><i class="fa fa-trash" style="color: #C9302C;font-size:18px"></i></a>
                        </td>
                    </tr>
                    @endforeach
                    @else
                    <tr>
                        <th colspan="6" align="center">No records found</th>
                    </tr>
                    @endif
                </tbody>
            </table>
            <div class="col-sm-12 text-right">{{ $results->links() }}</div>
        </div>
</section>
<script type="text/javascript">
            $(document).on('change', '#retailerIds', function () {
    if (!$(this).val().length) {
    window.location.href = "{{ route('aarticles') }}";
    } else {
    window.location.href = "{{ route('aarticles') }}" + "/" + $(this).val();
    }
    })
            function goDisableEnable(id, status) {
            var msgIs = (status == 0) ? "Disable" : "Enable";
                    swal({
                    title: "User " + msgIs,
                            text: "Please confirm, you want to " + msgIs + " this user?",
                            type: "info",
                            showCancelButton: true,
                            closeOnConfirm: false,
                            showLoaderOnConfirm: true,
                    }, function () {
                    setTimeout(function () {
                    window.location.href = "{{url('admin/enbleDisableGame')}}" + "/articles/" + id + "/" + status;
                    }, 2000);
                    });
            }
    function goDelete(id) {
    swal({
    title: "Article Delete",
            text: "Please confirm, you want to delete this article?",
            type: "error",
            showCancelButton: true,
            closeOnConfirm: false,
            showLoaderOnConfirm: true,
    },
            function () {
            setTimeout(function () {
            window.location.href = "{{url('admin/deleteGame')}}" + "/articles/" + id;
            }, 2000);
            });
    }

</script>

@endsection