@extends('layouts.admin')
@section('bc','Admin Dashboard')
@section('flag','Statistics and graph section')
@section('dbAct','activeMenu')
@section('content')
<?php //echo $arts;die; ?>
<section class="created">
    <div class="col-xs-12">
        @include('admin.adminMenu')
        <div class="col-sm-9 list_item pad-none">
            
            <div class="col-sm-7 row" style="margin-bottom: 35px;">
                <div class="well well-sm wellCustom">All Articles</div>
                <div id="saleschartArticles" class="chart"></div>
            </div>
            
            <div class="col-sm-5 row" style="margin-bottom: 35px;margin-left: 15px;">
                <div class="well well-sm wellCustom">Articles In Categories</div>
                <div id="pie-chart" class="chart"></div>
            </div>

            <div class="col-sm-12 row" style="margin-bottom: 35px;">
                <div class="well well-sm wellCustom">Retailers / Companies</div>
                <div id="saleschartCompanies" class="chart"></div>
            </div>

            <div class="col-sm-12 row">
                <div class="well well-sm wellCustom">Users</div>
                <div id="saleschartUsers" class="chart"></div>
            </div>
            
        </div>

</section>



<!-- IMPORTANT: APP CONFIG -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script src="{{ asset('public/js/bootstrap/app.config.js') }}"></script>
<script src="{{ asset('public/js/bootstrap/bootstrap.min.js') }}"></script>
<script src="{{ asset('public/js/bootstrap/app.min.js') }}"></script>


<!-- JARVIS WIDGETS -->
<script src="{{ asset('public/js/bootstrap/smartwidgets/jarvis.widget.min.js') }}"></script>

<!-- EASY PIE CHARTS -->
<script src="{{ asset('public/js/bootstrap/plugin/easy-pie-chart/jquery.easy-pie-chart.min.js') }}"></script>


<script src="{{ asset('public/js/bootstrap/plugin/flot/jquery.flot.cust.min.js') }}"></script>
<script src="{{ asset('public/js/bootstrap/plugin/flot/jquery.flot.resize.min.js') }}"></script>
<script src="{{ asset('public/js/bootstrap/plugin/flot/jquery.flot.fillbetween.min.js') }}"></script>
<script src="{{ asset('public/js/bootstrap/plugin/flot/jquery.flot.orderBar.min.js') }}"></script>
<script src="{{ asset('public/js/bootstrap/plugin/flot/jquery.flot.pie.min.js') }}"></script>
<script src="{{ asset('public/js/bootstrap/plugin/flot/jquery.flot.tooltip.min.js') }}"></script>


<script type="text/javascript">

        $(document).ready(function () {
var artFull = {};
        $.get("{{url('admin/chartsData')}}", function (data, status) {
        if (status == 'success') {
        var x = 0;
                $.each(data.art, function (kk, vv) {
                var artChart = [];
                        artChart.push(vv.artTime, vv.amount);
                        // x++;
                        artFull.push(artChart);
                });
                //artFull.push(artChart);
        }
        });
        $("#dpldata").text(artFull);
// PAGE RELATED SCRIPTS

        /* chart colors default */
        var $chrt_border_color = "#efefef";
        var $chrt_second = "#64B92D";
// DO NOT REMOVE : GLOBAL FUNCTIONS!
        //pageSetUp();
        /* sales chart */
        if ($("#saleschartArticles").length) {
var d = [{{ $arts }}];
        for (var i = 0; i < d.length; ++i)
        d[i][0] += 60 * 60 * 1000;
        function weekendAreas(axes) {
        var markings = [];
                var d = new Date(axes.xaxis.min);
                // go to the first Saturday
                d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 1) % 7))
                d.setUTCSeconds(0);
                d.setUTCMinutes(0);
                d.setUTCHours(0);
                var i = d.getTime();
                do {
                // when we don't set yaxis, the rectangle automatically
                // extends to infinity upwards and downwards
                markings.push({
                xaxis: {
                from: i,
                        to: i + 2 * 24 * 60 * 60 * 1000
                }
                });
                        i += 7 * 24 * 60 * 60 * 1000;
                } while (i < axes.xaxis.max);
                return markings;
        }

var options = {
xaxis: {
mode: "time",
        tickLength: 5
        },
        series: {
        lines: {
        show: true,
                lineWidth: 1,
                fill: true,
                fillColor: {
                colors: [{
                opacity: 0.1
                }, {
                opacity: 0.15
                }]
                }
        },
                points: { show: true },
                shadowSize: 0
        },
        selection: {
        mode: "x"
        },
        grid: {
        hoverable: true,
                clickable: true,
                tickColor: $chrt_border_color,
                borderWidth: 1,
                borderColor: $chrt_border_color,
        },
        tooltip: true,
        tooltipOpts: {
        content: "<div style='background-color:#64B92D;padding:5px;color:#fff'><span><b>%y</b></span> articles added on <b>%x</b></div>",
                dateFormat: "%y-%0m-%0d",
                defaultTheme: false
        },
        colors: [$chrt_second],
        };
        var plot = $.plot($("#saleschartArticles"), [d], options);
        }



if ($("#saleschartCompanies").length) {
var d = [{{$carts}}];
        for (var i = 0; i < d.length; ++i)
        d[i][0] += 60 * 60 * 1000;
        function weekendAreas(axes) {
        var markings = [];
                var d = new Date(axes.xaxis.min);
                // go to the first Saturday
                d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 1) % 7))
                d.setUTCSeconds(0);
                d.setUTCMinutes(0);
                d.setUTCHours(0);
                var i = d.getTime();
                do {
                // when we don't set yaxis, the rectangle automatically
                // extends to infinity upwards and downwards
                markings.push({
                xaxis: {
                from: i,
                        to: i + 2 * 24 * 60 * 60 * 1000
                }
                });
                        i += 7 * 24 * 60 * 60 * 1000;
                } while (i < axes.xaxis.max);
                return markings;
        }

var options = {
xaxis: {
mode: "time",
        tickLength: 5
        },
        series: {
        lines: {
        show: true,
                lineWidth: 1,
                fill: true,
                fillColor: {
                colors: [{
                opacity: 0.1
                }, {
                opacity: 0.15
                }]
                }
        },
                points: { show: true },
                shadowSize: 0
        },
        selection: {
        mode: "x"
        },
        grid: {
        hoverable: true,
                clickable: true,
                tickColor: $chrt_border_color,
                borderWidth: 0,
                borderColor: $chrt_border_color,
        },
        tooltip: true,
        tooltipOpts: {
        content: "<div style='background-color:#64B92D;padding:5px;color:#fff'><b>%y</b> retailer/company has joined on <b>%x</b></div>",
                dateFormat: "%y-%0m-%0d",
                defaultTheme: false
        },
        colors: [$chrt_second],
        };
        var plot = $.plot($("#saleschartCompanies"), [d], options);
        }

if ($("#saleschartUsers").length) {
var d = [{{$users}}];
        for (var i = 0; i < d.length; ++i)
        d[i][0] += 60 * 60 * 1000;
        function weekendAreas(axes) {
        var markings = [];
                var d = new Date(axes.xaxis.min);
                // go to the first Saturday
                d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 1) % 7))
                d.setUTCSeconds(0);
                d.setUTCMinutes(0);
                d.setUTCHours(0);
                var i = d.getTime();
                do {
                // when we don't set yaxis, the rectangle automatically
                // extends to infinity upwards and downwards
                markings.push({
                xaxis: {
                from: i,
                        to: i + 2 * 24 * 60 * 60 * 1000
                }
                });
                        i += 7 * 24 * 60 * 60 * 1000;
                } while (i < axes.xaxis.max);
                return markings;
        }

var options = {
xaxis: {
mode: "time",
        tickLength: 5
        },
        series: {
        lines: {
        show: true,
                lineWidth: 1,
                fill: true,
                fillColor: {
                colors: [{
                opacity: 0.1
                }, {
                opacity: 0.15
                }]
                }
        },
                points: { show: true },
                shadowSize: 0
        },
        selection: {
        mode: "x"
        },
        grid: {
        hoverable: true,
                clickable: true,
                tickColor: $chrt_border_color,
                borderWidth: 0,
                borderColor: $chrt_border_color,
        },
        tooltip: true,
        tooltipOpts: {
        content: "<div style='background-color:#64B92D;padding:5px;color:#fff'><b>%y</b> users has joined on <b>%x</b></div>",
                dateFormat: "%y-%0m-%0d",
                defaultTheme: false
        },
        colors: [$chrt_second],
        };
        var plot = $.plot($("#saleschartUsers"), [d], options);
        }
/* end sales chart */


/* pie chart */

if ($('#pie-chart').length) {

var data_pie = [];
        var series = Math.floor(Math.random() * 10) + 1;
        data_pie[0] = {
        label : " Restaurant",
        color: "#008080",
        data : {{$cats['res']}}
        };
        data_pie[1] = {
label : " Fast Food",
color:"#FF6347",
        data : {{$cats['fas']}}
        };
        data_pie[2] = {
label : " Coffee Shop",
color:"#895E2D",
        data : {{$cats['cof']}}
};
        data_pie[3] = {
label : " Pub",
color:"#B18FEE",
        data : {{$cats['pub']}}
};

        $.plot($("#pie-chart"), data_pie, {
        series : {
        pie : {
        show : true,
                innerRadius : 0.5,
                radius : 1,
                label : {
                show : false,
                        radius : 2 / 3,
                        formatter : function(label, series) {
                        return '<div style="font-size:11px;text-align:center;padding:4px;color:white;">' + label + '<br/>' + Math.round(series.percent) + '%</div>';
                        },
                        threshold : 0.1
                }
        }
        },
                legend : {
                show : true,
                        noColumns : 1, // number of colums in legend table
                        labelFormatter : null, // fn: string -> string
                        labelBoxBorderColor : "#000", // border color for the little label boxes
                        container : null, // container (as jQuery object) to put legend in, null means default on top of graph
                        position : "ne", // position of default legend container within plot
                        margin : [5, 10], // distance from grid edge to default legend container within plot
                        backgroundColor : "#efefef", // null means auto-detect
                        backgroundOpacity : 1 // set to 0 to avoid background
                },
                grid : {
                hoverable : true,
                        clickable : true
                },
        });
        }

/* end pie chart */

});
        /* end flot charts */

</script>


@endsection