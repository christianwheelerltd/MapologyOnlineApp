@extends('layouts.app')
@section('bc','Article')
<?php
$userName = userRow()->companyName;
$flag = "Hello " . $userName . ", let's start to publish some offers.";
?>
@section('flag',$flag)
@section('content')
<section class="created">
    <div class="col-xs-12">
        @include ('articles.form',['action' => "addArticle"])
    </div>
</section>
@endsection