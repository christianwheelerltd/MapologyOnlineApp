$(document).on('click','.allOverTopGreenDiv',function(){
    $(this).parent('div').fadeOut('slow');
});